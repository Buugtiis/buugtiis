 "use client";

import { useEffect, useMemo, useState } from "react";
import { supabase } from "../lib/supabase";

type Book = {
  id: string;
  title: string;
  author: string | null;
  description: string | null;
  cover_url: string | null;
  pdf_url: string | null;
  audio_url: string | null;
  category: string | null;
  price: number;
  is_free: boolean;
  created_at: string;
};

type Profile = { id: string; email: string | null; role: "user" | "admin" };

export default function Home() {
  const [tab, setTab] = useState("store");
  const [books, setBooks] = useState<Book[]>([]);
  const [library, setLibrary] = useState<string[]>([]);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [search, setSearch] = useState("");
  const [reader, setReader] = useState<Book | null>(null);
  const [authOpen, setAuthOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  const client = useMemo(() => {
    try { return supabase(); } catch { return null; }
  }, []);

  async function load() {
    if (!client) return;
    setLoading(true);
    const { data: b } = await client.from("books").select("*").order("created_at", { ascending: false });
    setBooks((b || []) as Book[]);
    const { data: { user } } = await client.auth.getUser();
    if (user) {
      const { data: p } = await client.from("profiles").select("id,email,role").eq("id", user.id).single();
      setProfile(p as Profile | null);
      const { data: l } = await client.from("library").select("book_id").eq("user_id", user.id);
      setLibrary((l || []).map((x: any) => x.book_id));
    } else {
      setProfile(null);
      setLibrary([]);
    }
    setLoading(false);
  }

  useEffect(() => {
    load();
    if (!client) return;
    const { data: listener } = client.auth.onAuthStateChange(() => load());
    return () => listener.subscription.unsubscribe();
  }, [client]);

  async function signOut() {
    if (!client) return;
    await client.auth.signOut();
    setProfile(null);
  }

  async function addFree(book: Book) {
    if (!client) return;
    if (!profile) { setAuthOpen(true); return; }
    const { error } = await client.from("library").upsert({ user_id: profile.id, book_id: book.id });
    if (error) alert(error.message); else { alert("Buugga waxaa lagu daray Library-ga."); load(); }
  }

  async function buy(book: Book) {
    if (!client) return;
    if (!profile) { setAuthOpen(true); return; }
    const { error } = await client.from("orders").insert({
      user_id: profile.id, book_id: book.id, amount: book.price, status: "pending"
    });
    if (error) alert(error.message);
    else alert("Dalabka waa la diiwaangeliyey. Payment gateway dhab ah ayaa lagu xirin karaa tallaabada xigta.");
  }

  const filtered = books.filter(b =>
    [b.title, b.author, b.category].filter(Boolean).join(" ").toLowerCase().includes(search.toLowerCase())
  );

  return (
    <main>
      <header className="topbar">
        <div className="brand" onClick={() => setTab("store")}>
          <div className="logo">B</div>
          <div><strong>BUUGTIIS</strong><small>Your Digital Library</small></div>
        </div>
        <div className="search"><span>⌕</span><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Raadi buug, qoraa..." /></div>
        <div className="account">
          {profile ? <><span className="hello">{profile.email}</span>{profile.role === "admin" && <button onClick={() => setAdminOpen(true)}>Admin</button>}<button onClick={signOut}>Ka bax</button></> : <button onClick={() => setAuthOpen(true)}>Login / Signup</button>}
        </div>
      </header>

      <nav className="nav">
        {[
          ["store","Book Store"],["library","Library"],["audio","Audiobooks"],["reading","Reading Now"]
        ].map(([id,label]) => <button key={id} className={tab===id ? "active" : ""} onClick={() => setTab(id)}>{label}</button>)}
      </nav>

      <section className="hero">
        <div><p className="eyebrow">BUUGTIIS</p><h1>Buug kasta,<br/><span>meel kasta.</span></h1><p>Akhriso, kaydi, oo dhageyso buugaagta aad jeceshahay — hal maktabad dijitaal ah.</p><button className="primary" onClick={() => setTab("store")}>Explore Books →</button></div>
        <div className="hero-card"><div className="book-stack">📚</div><b>Your Digital Library</b><span>Read • Listen • Learn</span></div>
      </section>

      <section className="content">
        <div className="section-head"><div><p className="eyebrow">DISCOVER</p><h2>{tab === "library" ? "My Library" : tab === "audio" ? "Audiobooks" : tab === "reading" ? "Continue Reading" : "Book Store"}</h2></div><span>{filtered.length} books</span></div>

        {loading ? <div className="empty">Loading...</div> :
          <div className="grid">
            {filtered.filter(b => tab === "audio" ? !!b.audio_url : tab === "library" ? library.includes(b.id) : true).map(book =>
              <article className="book" key={book.id} onClick={() => book.pdf_url && setReader(book)}>
                <div className="cover" style={{backgroundImage: book.cover_url ? `url(${book.cover_url})` : undefined}}>
                  {!book.cover_url && <span>📖</span>}
                  {book.is_free && <b className="badge">FREE</b>}
                </div>
                <div className="book-info"><h3>{book.title}</h3><p>{book.author || "Unknown author"}</p>
                  <div className="actions">
                    {book.pdf_url && <button onClick={(e)=>{e.stopPropagation();setReader(book)}}>Akhri</button>}
                    {book.is_free ? <button onClick={(e)=>{e.stopPropagation();addFree(book)}}>+ Library</button> : <button onClick={(e)=>{e.stopPropagation();buy(book)}}>${book.price.toFixed(2)}</button>}
                  </div>
                </div>
              </article>
            )}
          </div>
        }
        {!loading && filtered.length === 0 && <div className="empty">Buug aan raadineyno lama helin.</div>}
      </section>

      {reader && <div className="modal reader"><div className="reader-head"><b>{reader.title}</b><button onClick={()=>setReader(null)}>✕</button></div>
        {reader.pdf_url ? <iframe src={reader.pdf_url} title={reader.title}/> : <div className="empty">PDF lama gelin buuggan.</div>}
      </div>}

      {authOpen && <AuthModal client={client} close={()=>setAuthOpen(false)} refresh={load}/>}
      {adminOpen && profile?.role === "admin" && <AdminModal client={client} close={()=>setAdminOpen(false)} refresh={load}/>}
    </main>
  );
}

function AuthModal({client,close,refresh}: any) {
  const [signup,setSignup]=useState(false), [email,setEmail]=useState(""), [password,setPassword]=useState(""), [busy,setBusy]=useState(false);
  async function submit(e:any){
    e.preventDefault(); if(!client)return; setBusy(true);
    const result=signup ? await client.auth.signUp({email,password}) : await client.auth.signInWithPassword({email,password});
    setBusy(false);
    if(result.error) alert(result.error.message); else { if(signup) alert("Account-ka waa la sameeyey. Haddii email confirmation shidan yahay, email-ka xaqiiji."); close(); refresh(); }
  }
  return <div className="modal"><div className="dialog"><button className="x" onClick={close}>✕</button><div className="logo big">B</div><h2>{signup?"Create account":"Welcome back"}</h2><p>{signup?"Samee BUUGTIIS account":"Gal BUUGTIIS account-kaaga"}</p><form onSubmit={submit}><input type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required/><input type="password" placeholder="Password (ugu yaraan 6)" value={password} onChange={e=>setPassword(e.target.value)} minLength={6} required/><button className="primary full" disabled={busy}>{busy?"Fadlan sug...":signup?"Signup":"Login"}</button></form><button className="link" onClick={()=>setSignup(!signup)}>{signup?"Waxaan leeyahay account":"Create new account"}</button></div></div>
}

function AdminModal({client,close,refresh}: any) {
  const [title,setTitle]=useState(""),[author,setAuthor]=useState(""),[category,setCategory]=useState(""),[price,setPrice]=useState("0"),[free,setFree]=useState(true),[cover,setCover]=useState<File|null>(null),[pdf,setPdf]=useState<File|null>(null),[audio,setAudio]=useState<File|null>(null),[busy,setBusy]=useState(false);
  async function submit(e:any){
    e.preventDefault(); if(!client)return; setBusy(true);
    const upload=async(file:File|null,folder:string)=>{ if(!file)return null; const path=`${crypto.randomUUID()}-${file.name}`; const {error}=await client.storage.from("books").upload(`${folder}/${path}`,file,{upsert:false}); if(error)throw error; return client.storage.from("books").getPublicUrl(`${folder}/${path}`).data.publicUrl; };
    try {
      const cover_url=await upload(cover,"covers"), pdf_url=await upload(pdf,"pdfs"), audio_url=await upload(audio,"audio");
      const {error}=await client.from("books").insert({title,author,category,price:Number(price)||0,is_free:free,cover_url,pdf_url,audio_url});
      if(error)throw error; alert("Buugga waa la geliyey."); refresh(); close();
    } catch(err:any){alert(err.message)} finally{setBusy(false)}
  }
  return <div className="modal"><div className="dialog wide"><button className="x" onClick={close}>✕</button><h2>Admin Dashboard</h2><p>Ku dar buug cusub</p><form onSubmit={submit} className="admin-form"><input placeholder="Book title" value={title} onChange={e=>setTitle(e.target.value)} required/><input placeholder="Author" value={author} onChange={e=>setAuthor(e.target.value)}/><input placeholder="Category" value={category} onChange={e=>setCategory(e.target.value)}/><input type="number" step="0.01" placeholder="Price" value={price} onChange={e=>setPrice(e.target.value)}/><label><input type="checkbox" checked={free} onChange={e=>setFree(e.target.checked)}/> Free book</label><label>Cover image <input type="file" accept="image/*" onChange={e=>setCover(e.target.files?.[0]||null)}/></label><label>PDF <input type="file" accept="application/pdf" onChange={e=>setPdf(e.target.files?.[0]||null)}/></label><label>Audio <input type="file" accept="audio/*" onChange={e=>setAudio(e.target.files?.[0]||null)}/></label><button className="primary" disabled={busy}>{busy?"Uploading...":"Add Book"}</button></form></div></div>
}